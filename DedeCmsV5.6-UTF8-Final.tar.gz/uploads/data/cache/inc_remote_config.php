<?php
$remoteuploads = '0';
$remoteupUrl = 'http://img.dedecms.com';
$rmhost = '127.0.0.1';
$rmport = '21';
$rmname = 'dede';
$rmpwd = 'dede';
?>
