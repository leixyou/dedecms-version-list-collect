<?php
$s_tmplets = "templets/content_i_list.htm";
include(dirname(__FILE__)."/content_list.php");
?>