<?php
require_once(dirname(__FILE__)."/config.php");
require_once(DEDEADMIN."/templets/makehtml_freelist.htm");
?>