<?php
require_once(dirname(__FILE__)."/config.php");
require_once(DEDEINC."/typelink.class.php");
include DedeInclude('templets/makehtml_archives.htm');

?>